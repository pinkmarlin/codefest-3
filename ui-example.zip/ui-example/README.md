
Run `node server.js` to create the MCP server
Run `node cli.js` to run the cli demo