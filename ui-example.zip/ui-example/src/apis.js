export const fetchGuitars = async () => {
    return [
        {
            id: 1,
            name: 'Blue Grass Melter',
            image: '',
            description: 'Used in 2 world wars, this guitar has melted the faces of many souls through its sheer 🤘',
            shortDescription: 'GEETAR',
            price: 10000000
        }
    ];
  };
  